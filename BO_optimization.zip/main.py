# -*- coding: utf-8 -*-
"""
The main entry point for the Bayesian Optimization framework.
This version adds robust results management by creating a unique, timestamped
output directory for each optimization run, where all plots and data are saved.
"""
import argparse
import importlib
import os
from datetime import datetime

from src.bo_optimizer import BayesianOptimizer
from src.blackbox_wrapper import AeroEvaluation
from src.post_processing import plot_results
from src.history_logger import save_history_to_csv
from src.problem_structures import validate_optimization_config

def main(problem_module_name: str):
    """The main execution function."""
    print("--- Starting Bayesian Optimization ---")
    
    try:
        problem_module = importlib.import_module(problem_module_name)
        define_problem = getattr(problem_module, 'define_problem')
        print(f"Successfully loaded problem definition from: {problem_module_name}")
    except (ImportError, AttributeError) as e:
        print("\n" + "="*60)
        print("FATAL: Could not load the problem definition.")
        print(f"Error: {e}")
        print(f"Please ensure '{problem_module_name.replace('.', '/')}.py' exists and contains a 'define_problem' function.")
        print("="*60 + "\n")
        return

    problem_config = define_problem()
    validate_optimization_config(problem_config)
    
    # --- NEW: Create a unique directory for this run's results ---
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    run_name = problem_module_name.split('.')[-1]
    output_dir = os.path.join("results", f"{run_name}_{timestamp}")
    os.makedirs(output_dir, exist_ok=True)
    print(f"Results for this run will be saved in: {output_dir}")
    # ---

    optimizer = BayesianOptimizer(
        config=problem_config,
        black_box_class=AeroEvaluation
    )

    optimizer.run_optimization()

    # Pass the output directory to the saving and plotting functions
    history_filename = os.path.join(output_dir, "full_optimization_history.csv")
    save_history_to_csv(optimizer, history_filename)
    
    plot_results(optimizer, output_dir)

    print("\n--- Optimization Run Finished Successfully ---")
    print(f"Final results and plots are saved in: {output_dir}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run the Bayesian Optimization Framework.")
    parser.add_argument(
        "--problem",
        type=str,
        default="src.problem_def_multi_objective",
        help="The Python module path to the problem definition file (e.g., src.problem_def_multi_objective)"
    )
    args = parser.parse_args()
    main(problem_module_name=args.problem)

