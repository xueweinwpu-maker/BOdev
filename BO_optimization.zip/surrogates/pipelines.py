# -*- coding: utf-8 -*-
"""
This module defines the data-driven aerodynamic evaluation pipelines.
This version is updated to support inner-loop minimization by automatically
creating negative versions of key metrics (e.g., '-CD').
"""
import numpy as np
import pandas as pd
import torch
import sys
import os
from typing import Dict, Any, Optional, List

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from surrogates.model import GPyTorchSurrogateModel
from src.base_pipeline import AeroPipeline

class SurrogateBackedPipeline(AeroPipeline):
    """
    An aerodynamic evaluation pipeline that uses pre-trained GP surrogate models.
    """
    def __init__(self, mach_str: str, train_paths: List[str], inner_loop_objective: Optional[str] = None):
        self.mach_str = mach_str
        self.train_paths = train_paths
        self.inner_loop_objective = inner_loop_objective
        
        self.input_cols = [f'ratio[{i}]' for i in range(16)]
        self.output_cols = ['Cx', 'CY', 'CZ', 'CMx', 'CMY', 'CMZ']
        self.alpha = 4.0 * np.pi / 180.0

        self.models: Dict[str, GPyTorchSurrogateModel] = {}
        self._train_all_models()

    def _transform_coeffs(self, results_dict: Dict[str, float]):
        cl = results_dict['CY'] * np.cos(self.alpha) - results_dict['Cx'] * np.sin(self.alpha)
        cd = results_dict['CY'] * np.sin(self.alpha) + results_dict['Cx'] * np.cos(self.alpha)
        return cl, cd

    def _train_all_models(self):
        """Loads and combines all provided data files to train the final models."""
        print(f"--- Initializing Surrogate Pipeline for Ma = {self.mach_str} ---")
        
        all_dfs = []
        for path in self.train_paths:
            try:
                df = pd.read_csv(path)
                df.columns = df.columns.str.strip()
                df.dropna(inplace=True)
                all_dfs.append(df)
            except FileNotFoundError:
                print(f"WARNING: Could not find training data at {path}. Skipping this file.")

        if not all_dfs:
            print(f"FATAL: No training data could be loaded for Ma = {self.mach_str}. Exiting.")
            sys.exit(1)
        
        full_train_df = pd.concat(all_dfs, ignore_index=True)
        print(f"Combined {len(all_dfs)} file(s) into a single dataset of {len(full_train_df)} points.")

        train_x_torch = torch.tensor(full_train_df[self.input_cols].values)

        for coeff_name in self.output_cols:
            print(f"Training model for {coeff_name}...")
            train_y_torch = torch.tensor(full_train_df[coeff_name].values).unsqueeze(-1)
            model = GPyTorchSurrogateModel(train_x_torch, train_y_torch)
            model.train_model()
            self.models[coeff_name] = model
        
        print(f"--- Pipeline for Ma = {self.mach_str} is ready. ---")

    def run(self, offline_vars: np.ndarray, online_vars: Optional[np.ndarray]) -> Dict[str, Any]:
        if online_vars is not None:
            full_vars = np.concatenate([offline_vars, online_vars])
        else:
            full_vars = offline_vars

        if len(full_vars) != 16:
            raise ValueError(f"Pipeline expects 16 total variables, but received {len(full_vars)}")

        input_tensor = torch.tensor(full_vars, dtype=torch.double).reshape(1, -1)
        
        results = {}
        for coeff_name in self.output_cols:
            pred, _ = self.models[coeff_name].predict(input_tensor)
            results[coeff_name] = pred.item()

        cl, cd = self._transform_coeffs(results)
        results["CL"] = cl
        results["CD"] = cd
        results["K"] = cl / cd if cd > 1e-6 else 0.0
        results["Xcp"] = results['CMZ'] / results['CY'] if abs(results['CY']) > 1e-6 else 0.0
        
        # ** NEW: Add negative versions of metrics to support minimization **
        results["-CL"] = -cl
        results["-CD"] = -cd
        results["-K"] = -results["K"]

        if self.inner_loop_objective:
            if self.inner_loop_objective not in results:
                raise KeyError(f"The specified inner loop objective '{self.inner_loop_objective}' was not found in the pipeline results.")
            results["objective"] = results[self.inner_loop_objective]
        else:
            results["objective"] = None

        k_min_subsonic_val = results["K"] - 4.5
        k_min_supersonic_val = results["K"] - 3.5
        xcp_max_supersonic_val = 0.68 - results["Xcp"]
        cl_min_hypersonic_val = results["CL"] - 0.085
        xcp_max_hypersonic_val = 0.68 - results["Xcp"]
        
        results["constraints"] = [
            k_min_subsonic_val, 
            k_min_supersonic_val, 
            xcp_max_supersonic_val, 
            cl_min_hypersonic_val, 
            xcp_max_hypersonic_val
        ]

        return results

