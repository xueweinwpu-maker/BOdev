# -*- coding: utf-8 -*-
"""
This module defines the Gaussian Process surrogate model using GPyTorch and BoTorch.
This version is updated to save all validation results (plots and metrics)
into a structured, timestamped output directory at high resolution.
"""
import torch
import gpytorch
from botorch.models import SingleTaskGP
from botorch.fit import fit_gpytorch_mll
from gpytorch.mlls import ExactMarginalLogLikelihood
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import matplotlib.pyplot as plt
import scipy.stats as stats
import sys
import os
from datetime import datetime

class GPyTorchSurrogateModel:
    """
    A wrapper for a single-output Gaussian Process model using GPyTorch/BoTorch.
    It uses a Matern kernel with Automatic Relevance Determination (ARD) and
    handles input/output scaling internally.
    """
    def __init__(self, train_x: torch.Tensor, train_y: torch.Tensor):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.dtype = torch.double
        
        self.x_scaler = MinMaxScaler()
        self.y_scaler = StandardScaler()

        self.train_x_scaled = torch.tensor(self.x_scaler.fit_transform(train_x), device=self.device, dtype=self.dtype)
        self.train_y_scaled = torch.tensor(self.y_scaler.fit_transform(train_y), device=self.device, dtype=self.dtype)

        self.model = None
        print(f"Model initialized on device: {self.device}. Input/Output scaling has been applied.")

    def _build_model(self):
        """Builds the SingleTaskGP model with an ARD Matern kernel."""
        self.model = SingleTaskGP(
            train_X=self.train_x_scaled,
            train_Y=self.train_y_scaled,
            covar_module=gpytorch.kernels.ScaleKernel(
                gpytorch.kernels.MaternKernel(nu=2.5, ard_num_dims=self.train_x_scaled.shape[-1])
            )
        ).to(self.device, dtype=self.dtype)

    def train_model(self):
        """Trains the GP model by fitting the marginal log likelihood."""
        if self.model is None:
            self._build_model()
        print("Training surrogate model on scaled data...")
        mll = ExactMarginalLogLikelihood(self.model.likelihood, self.model)
        fit_gpytorch_mll(mll)
        print("Training complete.")

    def predict(self, test_x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Makes predictions with the trained model."""
        if self.model is None:
            raise RuntimeError("Model has not been trained yet.")
        self.model.eval()

        test_x_scaled = torch.tensor(self.x_scaler.transform(test_x), device=self.device, dtype=self.dtype)

        with torch.no_grad(), gpytorch.settings.fast_pred_var():
            posterior = self.model(test_x_scaled)
            mean_scaled = posterior.mean.cpu().numpy().reshape(-1, 1)
            mean_unscaled = torch.tensor(self.y_scaler.inverse_transform(mean_scaled), device=self.device, dtype=self.dtype)
            variance_scaled = posterior.variance 
            return mean_unscaled, variance_scaled

    @staticmethod
    def validate_model(model, test_x: torch.Tensor, test_y: torch.Tensor, name: str = "", output_dir: str = "."):
        """
        Validates the model, saves a comprehensive 2x2 plot, and saves metrics to a text file.
        """
        plt.style.use('seaborn-v0_8-whitegrid')

        print(f"\n--- Validating Model for {name} ---")
        pred_y_mean, _ = model.predict(test_x)
        pred_y_mean_np = pred_y_mean.cpu().numpy().flatten()
        test_y_np = test_y.cpu().numpy().flatten()

        r2 = r2_score(test_y_np, pred_y_mean_np)
        rmse = np.sqrt(mean_squared_error(test_y_np, pred_y_mean_np))
        mae = mean_absolute_error(test_y_np, pred_y_mean_np)
        residuals = test_y_np - pred_y_mean_np
        max_ae = np.max(np.abs(residuals))

        metrics_str = (
            f"--- Validation Metrics for {name} ---\n"
            f"R-squared (R2):                  {r2:.6f}\n"
            f"Root Mean Squared Error (RMSE):    {rmse:.6f}\n"
            f"Mean Absolute Error (MAE):         {mae:.6f}\n"
            f"Maximum Absolute Error (MaxAE):    {max_ae:.6f}\n"
        )
        print(metrics_str)
        
        with open(os.path.join(output_dir, "validation_metrics.txt"), "a") as f:
            f.write(metrics_str + "\n")

        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle(f'Surrogate Model Validation: {name}', fontsize=22, weight='bold')

        ax1 = axes[0, 0]
        ax1.scatter(test_y_np, pred_y_mean_np, alpha=0.6, edgecolors='k', s=50, facecolors='#2c7bb6')
        lims = [np.min([ax1.get_xlim(), ax1.get_ylim()]), np.max([ax1.get_xlim(), ax1.get_ylim()])]
        ax1.plot(lims, lims, 'k--', alpha=0.75, zorder=0, label='Ideal Fit')
        ax1.set_xlabel("True Values", fontsize=14); ax1.set_ylabel("Predicted Values", fontsize=14)
        ax1.set_title("True vs. Predicted Values", fontsize=16, weight='bold'); ax1.grid(True); ax1.legend()

        ax2 = axes[0, 1]
        ax2.scatter(pred_y_mean_np, residuals, alpha=0.6, edgecolors='k', s=50, facecolors='#abd9e9')
        ax2.axhline(y=0, color='k', linestyle='--', alpha=0.75, label='Zero Error')
        ax2.set_xlabel("Predicted Values", fontsize=14); ax2.set_ylabel("Residuals (True - Predicted)", fontsize=14)
        ax2.set_title("Residual Plot", fontsize=16, weight='bold'); ax2.grid(True); ax2.legend()
        
        ax3 = axes[1, 0]
        ax3.hist(residuals, bins=20, density=True, alpha=0.7, color='#fdae61', edgecolor='black')
        mu, std = stats.norm.fit(residuals)
        xmin, xmax = ax3.get_xlim(); x = np.linspace(xmin, xmax, 100); p = stats.norm.pdf(x, mu, std)
        ax3.plot(x, p, 'k-', linewidth=2, label='Normal Dist. Fit')
        ax3.set_xlabel("Residual Value", fontsize=14); ax3.set_ylabel("Density", fontsize=14)
        ax3.set_title("Distribution of Residuals", fontsize=16, weight='bold'); ax3.legend()

        ax4 = axes[1, 1]
        stats.probplot(residuals, dist="norm", plot=ax4)
        ax4.get_lines()[0].set_markerfacecolor('#d7191c'); ax4.get_lines()[0].set_markeredgecolor('k'); ax4.get_lines()[0].set_markersize(7.0)
        ax4.get_lines()[1].set_color('k'); ax4.get_lines()[1].set_linestyle('--')
        ax4.set_title("Normal Q-Q Plot of Residuals", fontsize=16, weight='bold')
        ax4.set_xlabel("Theoretical Quantiles", fontsize=14); ax4.set_ylabel("Sample Quantiles", fontsize=14)
        
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        
        plot_filename = f"validation_{name.replace('(', '').replace(')', '').replace('=', '').replace(' ', '_')}.png"
        # ** STYLE: Increase DPI for higher resolution **
        fig.savefig(os.path.join(output_dir, plot_filename), dpi=300)
        plt.close(fig)

    @staticmethod
    def plot_ard_relevance(model, name: str = "", output_dir: str = "."):
        """
        Extracts, plots, and saves the ARD length-scales from the model's kernel.
        """
        plt.style.use('seaborn-v0_8-whitegrid')
        
        if hasattr(model.model.covar_module, 'base_kernel') and hasattr(model.model.covar_module.base_kernel, 'lengthscale'):
            lengthscales = model.model.covar_module.base_kernel.lengthscale.squeeze().detach().cpu().numpy()
            relevance = 1 / lengthscales
            
            num_vars = len(relevance)
            var_names = [f'ratio[{i}]' for i in range(num_vars)]
            
            sorted_indices = np.argsort(relevance)[::-1]
            sorted_relevance = relevance[sorted_indices]
            sorted_names = [var_names[i] for i in sorted_indices]
            
            fig, ax = plt.subplots(figsize=(14, 8))
            bars = ax.bar(sorted_names, sorted_relevance, color='#4575b4', edgecolor='black')
            ax.set_xlabel('Design Variable (FFD Control Point)', fontsize=14)
            ax.set_ylabel('ARD Relevance (1 / Length-scale)', fontsize=14)
            ax.set_title(f'Automatic Relevance Determination for {name}', fontsize=18, weight='bold')
            plt.xticks(rotation=45, ha='right')
            ax.grid(axis='y', linestyle='--', alpha=0.7)
            plt.tight_layout()

            plot_filename = f"ard_{name.replace('(', '').replace(')', '').replace('=', '').replace(' ', '_')}.png"
            # ** STYLE: Increase DPI for higher resolution **
            fig.savefig(os.path.join(output_dir, plot_filename), dpi=300)
            plt.close(fig)
        else:
            print("Could not find ARD length-scales in the model kernel.")


if __name__ == '__main__':
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

    print("--- Testing surrogates/model.py ---")
    
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    output_dir = os.path.join("validation_results", f"run_{timestamp}")
    os.makedirs(output_dir, exist_ok=True)
    print(f"Validation results will be saved to: {output_dir}")
    
    input_cols = [f'ratio[{i}]' for i in range(16)]
    alpha = 4.0 * np.pi / 180.0
    
    def run_validation_for_mach(mach_str: str, train_path: str, verify_path: str, out_dir: str):
        print(f"\n--- Running Test for Ma = {mach_str} ---")
        try:
            train_df = pd.read_csv(train_path)
            verify_df = pd.read_csv(verify_path)
            
            train_df.columns = train_df.columns.str.strip()
            verify_df.columns = verify_df.columns.str.strip()
            train_df.dropna(inplace=True); verify_df.dropna(inplace=True)
        except FileNotFoundError:
            print(f"Error: Could not find Ma={mach_str} data files.")
            return

        train_x_torch = torch.tensor(train_df[input_cols].values)
        verify_x_torch = torch.tensor(verify_df[input_cols].values)
        
        for coeff_name in ['CY', 'Cx', 'CMZ']:
            train_y_torch = torch.tensor(train_df[coeff_name].values).unsqueeze(-1)
            verify_y_torch = torch.tensor(verify_df[coeff_name].values).unsqueeze(-1)
            
            model = GPyTorchSurrogateModel(train_x_torch, train_y_torch)
            model.train_model()
            
            GPyTorchSurrogateModel.validate_model(model, verify_x_torch, verify_y_torch, name=f"{coeff_name} (Ma={mach_str})", output_dir=out_dir)
            GPyTorchSurrogateModel.plot_ard_relevance(model, name=f"{coeff_name} (Ma={mach_str})", output_dir=out_dir)

    run_validation_for_mach("0.4", "data/train_dataM04.csv", "data/verify_dataM04.csv", output_dir)
    run_validation_for_mach("3.0", "data/train_dataM3.csv", "data/verify_dataM3.csv", output_dir)
    run_validation_for_mach("10.0", "data/train_dataM10.csv", "data/verify_dataM10.csv", output_dir)
    
    print(f"\n--- Validation testing complete. All results saved in {output_dir} ---")

