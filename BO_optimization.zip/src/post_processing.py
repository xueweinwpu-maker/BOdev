# -*- coding: utf-8 -*-
"""
Module for post-processing and visualizing optimization results.
This version is updated to save all generated plots to a specified
output directory, making it suitable for long, unattended runs.
"""
import numpy as np
import matplotlib.pyplot as plt
import torch
import pandas as pd
import os
from botorch.utils.multi_objective.pareto import is_non_dominated
from src.bo_optimizer import BayesianOptimizer

def _plot_parallel_coordinates(optimizer: BayesianOptimizer, output_dir: str):
    """
    Generates and saves a parallel coordinates plot for the final Pareto front.
    """
    print("\n--- Generating Parallel Coordinates Plot ---")
    history = optimizer.full_run_history
    if not history: return

    final_y_obj = optimizer.train_y_obj.cpu().numpy()
    final_y_con = optimizer.train_y_con.cpu().numpy()
    final_x = optimizer.train_x.cpu().numpy()

    feasible_mask = (final_y_con >= 0).all(axis=1)
    if not np.any(feasible_mask):
        print("No feasible points found to generate parallel coordinates plot.")
        return

    feasible_obj_tensor = torch.from_numpy(final_y_obj[feasible_mask])
    pareto_mask = is_non_dominated(feasible_obj_tensor)
    original_feasible_indices = np.where(feasible_mask)[0]
    pareto_indices = original_feasible_indices[pareto_mask.cpu().numpy()]

    if len(pareto_indices) == 0:
        print("No Pareto optimal points found to plot.")
        return

    pareto_x = final_x[pareto_indices]
    pareto_y = final_y_obj[pareto_indices]
    
    online_history_by_dp = {dp.name: [] for dp in optimizer.config.design_points}
    for item in history:
        for dp_name, online_vars in item["converged_online_vars"].items():
            online_history_by_dp[dp_name].append(online_vars)

    pareto_online_vars = {}
    for dp_name, data in online_history_by_dp.items():
        if data:
            data_np = np.array([d if d is not None else [np.nan] for d in data])
            pareto_online_vars[dp_name] = data_np[pareto_indices]

    data_dict = {}
    obj_names = [obj.name for obj in optimizer.config.objectives]
    for i, name in enumerate(obj_names):
        data_dict[name] = pareto_y[:, i]
        
    for i in range(pareto_x.shape[1]):
        data_dict[f'offline_var_{i}'] = pareto_x[:, i]
        
    for dp_name, online_data in pareto_online_vars.items():
        if online_data.ndim > 1:
            for i in range(online_data.shape[1]):
                data_dict[f'{dp_name}_online_var_{i}'] = online_data[:, i]

    df = pd.DataFrame(data_dict)

    fig = plt.figure(figsize=(20, 10))
    pd.plotting.parallel_coordinates(df, class_column=obj_names[0], colormap='viridis', linewidth=2.5)
    plt.title('Parallel Coordinates of Pareto Optimal Solutions', fontsize=18)
    plt.xlabel('Design Variables and Objectives', fontsize=14)
    plt.ylabel('Value', fontsize=14)
    plt.xticks(rotation=45, ha='right')
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()
    
    # Save the figure
    fig.savefig(os.path.join(output_dir, "parallel_coordinates_plot.png"))
    plt.close(fig)

def _plot_single_objective_results(optimizer: BayesianOptimizer, output_dir: str):
    """Generates and saves the convergence plot for a single-objective problem."""
    fig, ax = plt.subplots(figsize=(12, 7))
    iterations = np.arange(1, len(optimizer.convergence_history) + 1)
    ax.plot(iterations, optimizer.convergence_history, marker='o', linestyle='-', color='navy')
    ax.set_title("Convergence History", fontsize=16)
    ax.set_xlabel("Evaluation Number (Initial Samples + BO Iterations)", fontsize=12)
    ax.set_ylabel(f"Best Feasible: {optimizer.config.objectives[0].name}", fontsize=12)
    ax.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()
    fig.savefig(os.path.join(output_dir, "convergence_history.png"))
    plt.close(fig)

def _plot_multi_objective_results(optimizer: BayesianOptimizer, output_dir: str):
    """Generates and saves the Pareto front and hypervolume convergence plots."""
    final_y_obj = optimizer.train_y_obj.cpu().numpy()
    final_y_con = optimizer.train_y_con.cpu().numpy()
    objective_names = [obj.name for obj in optimizer.config.objectives]
    feasible_mask = (final_y_con >= 0).all(axis=1)

    # Plot Objective Space / Pareto Front
    fig1 = plt.figure(figsize=(10, 8))
    if final_y_obj.shape[1] in [2, 3]:
        ax1 = fig1.add_subplot(111, projection='3d' if final_y_obj.shape[1] == 3 else None)
        ax1.scatter(*final_y_obj[~feasible_mask].T, c='gray', s=30, alpha=0.5, label='Infeasible')
        ax1.scatter(*final_y_obj[feasible_mask].T, c='blue', s=50, alpha=0.7, label='Feasible')
        if np.any(feasible_mask):
            feasible_obj_tensor = torch.from_numpy(final_y_obj[feasible_mask])
            pareto_mask = is_non_dominated(feasible_obj_tensor)
            pareto_points = feasible_obj_tensor[pareto_mask].cpu().numpy()
            ax1.scatter(*pareto_points.T, c='red', s=120, marker='*', label='Pareto Front')

        ax1.set_xlabel(objective_names[0], fontsize=12)
        ax1.set_ylabel(objective_names[1], fontsize=12)
        if final_y_obj.shape[1] == 3:
            ax1.set_zlabel(objective_names[2], fontsize=12)
        ax1.set_title("Optimization Results: Objective Space", fontsize=16)
        ax1.legend()
        ax1.grid(True)
        fig1.savefig(os.path.join(output_dir, "pareto_front.png"))
    plt.close(fig1)

    # Plot Hypervolume Convergence
    fig2, ax2 = plt.subplots(figsize=(12, 7))
    iterations = np.arange(1, len(optimizer.convergence_history) + 1)
    ax2.plot(iterations, optimizer.convergence_history, marker='o', linestyle='-', color='purple')
    ax2.set_title("Hypervolume Convergence", fontsize=16)
    ax2.set_xlabel("Evaluation Number (Initial Samples + BO Iterations)", fontsize=12)
    ax2.set_ylabel("Hypervolume", fontsize=12)
    ax2.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()
    fig2.savefig(os.path.join(output_dir, "hypervolume_convergence.png"))
    plt.close(fig2)

def plot_acquisition_convergence(optimizer: BayesianOptimizer, output_dir: str):
    """Generates and saves the convergence plot for the acquisition function value."""
    if not optimizer.acqf_value_history: return
    print("\n--- Generating Acquisition Function Convergence Plot ---")
    
    fig, ax = plt.subplots(figsize=(12, 7))
    iterations = np.arange(1, len(optimizer.acqf_value_history) + 1)
    ax.plot(iterations, optimizer.acqf_value_history, marker='.', linestyle='--', color='darkorange')
    ax.set_title("Acquisition Function Value Convergence", fontsize=16)
    ax.set_xlabel("BO Iteration Number", fontsize=12)
    ax.set_ylabel("Max Acquisition Function Value", fontsize=12)
    ax.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()
    fig.savefig(os.path.join(output_dir, "acquisition_convergence.png"))
    plt.close(fig)

def plot_results(optimizer: BayesianOptimizer, output_dir: str):
    """The main function to generate and save all relevant plots."""
    print("\n--- Generating and Saving Plots ---")
    if optimizer.is_multi_objective:
        _plot_multi_objective_results(optimizer, output_dir)
        _plot_parallel_coordinates(optimizer, output_dir)
    else:
        _plot_single_objective_results(optimizer, output_dir)
    
    plot_acquisition_convergence(optimizer, output_dir)
    # The following plots are useful for debugging but can be verbose.
    # They will still be generated and saved.
    # plot_online_vars_evolution(optimizer) 
    # plot_inner_loop_histories(optimizer)
    
    # We will show the main convergence plot at the end of the run
    # for immediate feedback, even though it's saved.
    if optimizer.is_multi_objective:
        fig, ax = plt.subplots(figsize=(12, 7))
        iterations = np.arange(1, len(optimizer.convergence_history) + 1)
        ax.plot(iterations, optimizer.convergence_history, marker='o', linestyle='-', color='purple')
        ax.set_title("Hypervolume Convergence", fontsize=16)
        ax.set_xlabel("Evaluation Number", fontsize=12)
        ax.set_ylabel("Hypervolume", fontsize=12)
        ax.grid(True)
        plt.show()
    else:
        fig, ax = plt.subplots(figsize=(12, 7))
        iterations = np.arange(1, len(optimizer.convergence_history) + 1)
        ax.plot(iterations, optimizer.convergence_history, marker='o', linestyle='-', color='navy')
        ax.set_title("Convergence History", fontsize=16)
        ax.set_xlabel("Evaluation Number", fontsize=12)
        ax.set_ylabel(f"Best Feasible: {optimizer.config.objectives[0].name}", fontsize=12)
        ax.grid(True)
        plt.show()

