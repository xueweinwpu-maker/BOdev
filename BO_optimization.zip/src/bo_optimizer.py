# -*- coding: utf-8 -*-
"""
The main Bayesian Optimizer class.
This version includes clarifying comments regarding the role of outer-loop
constraints in the context of a bi-level optimization with inner-loop constraints.
"""
import torch
import warnings
import numpy as np
import gpytorch

from botorch.models.gp_regression import SingleTaskGP
from botorch.models.model_list_gp_regression import ModelListGP
from botorch.models.transforms.outcome import Standardize
from botorch.fit import fit_gpytorch_mll
from gpytorch.mlls import ExactMarginalLogLikelihood
from botorch.optim import optimize_acqf
from botorch.acquisition.multi_objective import qExpectedHypervolumeImprovement
from botorch.acquisition.objective import ConstrainedMCObjective
from botorch.acquisition.multi_objective.objective import IdentityMCMultiOutputObjective
from botorch.acquisition import qExpectedImprovement
from botorch.utils.multi_objective.hypervolume import Hypervolume
from botorch.utils.multi_objective.pareto import is_non_dominated
from botorch.utils.multi_objective.box_decompositions.non_dominated import FastNondominatedPartitioning
from botorch.utils.sampling import draw_sobol_samples
from botorch.utils.transforms import normalize, unnormalize

from src.problem_structures import OptimizationConfig
from src.blackbox_wrapper import BlackBox


class BayesianOptimizer:
    """
    Manages the entire Bayesian Optimization loop.
    """
    def __init__(self, config: OptimizationConfig, black_box_class: type[BlackBox]):
        self.config = config
        self.black_box = black_box_class(config)
        self.device = config.offline_bounds.device
        self.dtype = config.offline_bounds.dtype

        self.train_x, self.train_y_obj, self.train_y_con = None, None, None
        self.convergence_history = []
        self.acqf_value_history = []
        self.is_multi_objective = None
        self.full_run_history = []
        self.full_online_history = []
        self.ref_point = None

    def _print_evaluation_results(self, y_obj_point, y_con_point):
        """Prints named objectives and constraints."""
        obj_values = y_obj_point.cpu().numpy().flatten()
        con_values = y_con_point.cpu().numpy().flatten()
        
        print("  > Results:")
        for i, obj in enumerate(self.config.objectives):
            print(f"    - Objective '{obj.name}': {obj_values[i]:.4f}")
        # Note: self.config.constraints now only contains GLOBAL constraints.
        # Local constraints are handled by the inner loops.
        if self.config.constraints:
            for i, con in enumerate(self.config.constraints):
                status = "Satisfied" if con_values[i] >= 0 else "Violated"
                print(f"    - Global Constraint '{con.name}': {con_values[i]:.4f} ({status})")

    def _initialize_data(self):
        """
        Generates initial data points, using user-specified points first,
        then filling the rest with a Sobol sequence.
        """
        num_user_points = 0
        initial_x_list = []

        if self.config.user_initial_points is not None:
            user_points = self.config.user_initial_points
            num_user_points = user_points.shape[0]
            print(f"Using {num_user_points} user-specified initial design point(s).")
            initial_x_list.append(user_points)

        num_random_points = self.config.n_initial_samples - num_user_points
        if num_random_points > 0:
            print(f"Generating {num_random_points} random initial design points...")
            random_points = draw_sobol_samples(
                bounds=self.config.offline_bounds, n=num_random_points, q=1
            ).squeeze(-2)
            initial_x_list.append(random_points)
        
        initial_x = torch.cat(initial_x_list, dim=0).to(self.device, self.dtype)

        for i in range(self.config.n_initial_samples):
            x_point = initial_x[i].unsqueeze(0)
            eval_type = "User-Specified" if i < num_user_points else "Random"
            print(f"\n--- Evaluating Initial Point {i+1}/{self.config.n_initial_samples} ({eval_type}) ---")
            
            y_obj_point, y_con_point = self.black_box.evaluate(x_point)
            self._print_evaluation_results(y_obj_point, y_con_point)
            self.full_online_history.append(self.black_box.last_run_converged_online)

            if i == 0:
                self.train_x, self.train_y_obj, self.train_y_con = x_point, y_obj_point, y_con_point
            else:
                self.train_x = torch.cat([self.train_x, x_point], dim=0)
                self.train_y_obj = torch.cat([self.train_y_obj, y_obj_point], dim=0)
                self.train_y_con = torch.cat([self.train_y_con, y_con_point], dim=0)
            
            self.is_multi_objective = self.train_y_obj.shape[-1] > 1
            if self.is_multi_objective and self.ref_point is None:
                self.ref_point = self.train_y_obj.min(dim=0).values - 0.2 * abs(self.train_y_obj.min(dim=0).values)
            
            self._update_convergence_metric()
            self._log_iteration_data(is_initial_point=True)


    def _log_iteration_data(self, is_initial_point=False):
        """Logs the complete state of the latest iteration."""
        iteration_data = {
            "offline_vars": self.train_x[-1].cpu().numpy(),
            "objectives": self.train_y_obj[-1].cpu().numpy(),
            "constraints": self.train_y_con[-1].cpu().numpy(),
            "converged_online_vars": self.black_box.last_run_converged_online,
            "design_point_results": self.black_box.last_run_results_map,
            "convergence_metric": self.convergence_history[-1] if self.convergence_history else None,
            "acqf_value": self.acqf_value_history[-1] if not is_initial_point and self.acqf_value_history else None
        }
        self.full_run_history.append(iteration_data)

    def _update_convergence_metric(self):
        """Calculates and stores the current convergence metric."""
        feasible_mask = (self.train_y_con >= 0).all(dim=-1)
        if not feasible_mask.any():
            print("No feasible points found yet.")
            self.convergence_history.append(0.0 if self.is_multi_objective else np.nan)
            return

        if self.is_multi_objective:
            if self.ref_point is None:
                raise RuntimeError("Reference point for hypervolume is not set.")
            pareto_front = self.train_y_obj[feasible_mask][is_non_dominated(self.train_y_obj[feasible_mask])]
            hv = Hypervolume(ref_point=self.ref_point).compute(pareto_front)
            print(f"Current Hypervolume: {hv:.4f}")
            self.convergence_history.append(hv)
        else:
            best_val = self.train_y_obj[feasible_mask].max().item()
            print(f"Current Best Feasible Objective: {best_val:.4f}")
            self.convergence_history.append(best_val)

    def _get_and_fit_model(self):
        """Initializes and fits a ModelListGP with an ARD kernel."""
        normalized_train_x = normalize(self.train_x, self.config.offline_bounds)
        full_train_y = torch.cat([self.train_y_obj, self.train_y_con], dim=-1)

        models = []
        for i in range(full_train_y.shape[-1]):
            train_y_i = full_train_y[:, [i]]
            model = SingleTaskGP(
                train_X=normalized_train_x,
                train_Y=train_y_i,
                outcome_transform=Standardize(m=1),
                covar_module=gpytorch.kernels.ScaleKernel(
                    gpytorch.kernels.MaternKernel(nu=2.5, ard_num_dims=normalized_train_x.shape[-1])
                )
            )
            models.append(model)
        
        model_list = ModelListGP(*models)
        mll = gpytorch.mlls.SumMarginalLogLikelihood(model_list.likelihood, model_list)
        fit_gpytorch_mll(mll)
        return model_list

    def _optimize_acquisition_function(self):
        """Optimizes the acquisition function and returns candidates and acqf value."""
        model = self._get_and_fit_model()
        num_objectives = self.train_y_obj.shape[-1]

        if self.is_multi_objective:
            objective = IdentityMCMultiOutputObjective(outcomes=list(range(num_objectives)))
            constraints = [lambda Y, i=i: Y[..., num_objectives + i] for i in range(self.train_y_con.shape[-1])] if self.config.constraints else None
            acq_func = qExpectedHypervolumeImprovement(
                model=model, ref_point=self.ref_point,
                partitioning=FastNondominatedPartitioning(ref_point=self.ref_point, Y=self.train_y_obj),
                objective=objective, constraints=constraints
            )
        else:
            infeasible_cost = self.train_y_obj.min() - 1.0 * self.train_y_obj.std() if self.train_y_obj.numel() > 1 else -1e6
            objective = ConstrainedMCObjective(
                objective=lambda Y, X=None: Y[..., 0],
                constraints=[lambda Y, X=None: Y[..., 1 + i] for i in range(self.train_y_con.shape[-1])] if self.config.constraints else None,
                infeasible_cost=infeasible_cost
            )
            feasible_obj = self.train_y_obj[(self.train_y_con >= 0).all(dim=-1)]
            best_f = -torch.tensor(float('inf')) if not feasible_obj.numel() else feasible_obj.max()
            acq_func = qExpectedImprovement(model=model, best_f=best_f, objective=objective)

        normalized_bounds = torch.tensor([[0.0] * self.config.offline_dim, [1.0] * self.config.offline_dim], device=self.device, dtype=self.dtype)
        
        candidates, acqf_value = optimize_acqf(
            acq_function=acq_func,
            bounds=normalized_bounds,
            q=self.config.batch_size,
            num_restarts=self.config.num_restarts,
            raw_samples=self.config.raw_samples,
        )
        return unnormalize(candidates, self.config.offline_bounds), acqf_value

    def run_optimization(self):
        """Executes the full optimization loop."""
        self._initialize_data()
        
        if self.is_multi_objective:
            print(f"Multi-objective problem detected. HV ref point: {self.ref_point.cpu().numpy()}")
        else:
            print("Single-objective problem detected.")

        for i in range(self.config.n_bo_iterations):
            print(f"\n--- BO Iteration {i+1}/{self.config.n_bo_iterations} ---")
            print("Fitting surrogate model...")
            
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                new_x, new_acqf_value = self._optimize_acquisition_function()
            
            self.acqf_value_history.append(new_acqf_value.item())
            print(f"Optimized Acquisition Function Value: {new_acqf_value.item():.4f}")

            print("Evaluating new candidate points...")
            new_y_obj, new_y_con = self.black_box.evaluate(new_x)
            
            self._print_evaluation_results(new_y_obj, new_y_con)
            self.full_online_history.append(self.black_box.last_run_converged_online)
            
            self.train_x = torch.cat([self.train_x, new_x])
            self.train_y_obj = torch.cat([self.train_y_obj, new_y_obj])
            self.train_y_con = torch.cat([self.train_y_con, new_y_con])
            
            self._update_convergence_metric()
            self._log_iteration_data()

        print("\n--- Optimization Finished ---")

