# -*- coding: utf-8 -*-
"""
This module defines the central, shared data structures for the optimization framework.
This version includes a validation helper function and enhanced documentation
to ensure robust and clear problem configuration.
"""
from dataclasses import dataclass, field
from typing import List, Tuple, Callable, Dict, Any, Optional
import torch
from collections import defaultdict

from src.base_pipeline import AeroPipeline

@dataclass
class Objective:
    """Defines a single objective for the outer optimization problem."""
    name: str
    # Note: The callable should be robust. For example, using a small, named function
    # that handles potential missing keys in the results map is safer than a bare lambda.
    eval_function: Callable[[Dict[str, Dict[str, Any]]], float]

@dataclass
class InnerConstraint:
    """
    Defines a single INNER-LOOP constraint for a specific design point.
    The eval_function takes the pipeline's full result dictionary and must
    be formulated such that a value >= 0 indicates a satisfied constraint.
    """
    name: str
    description: str
    eval_function: Callable[[Dict[str, Any]], float]

@dataclass
class InnerOptConfig:
    """Configuration for the inner-loop optimization of online variables."""
    bounds: List[Tuple[float, float]]
    x0: List[float]
    constraints: List[InnerConstraint] = field(default_factory=list)
    method: str = "SLSQP"
    maxiter: int = 100
    tol: float = 1e-6

@dataclass
class DesignPoint:
    """Defines a single flight condition and its associated settings."""
    name: str
    pipeline: AeroPipeline
    inner_opt_config: Optional[InnerOptConfig] = None

@dataclass
class GlobalConstraint:
    """
    Defines a single GLOBAL constraint for the outer optimization problem.
    """
    name: str
    description: str
    # Note: The callable should be robust. It must handle cases where a design point
    # might be missing from the results map, returning a numeric failure value or
    # raising a clear error instead of failing silently.
    eval_function: Callable[[Dict[str, Dict[str, Any]]], float]

@dataclass
class OptimizationConfig:
    """The main container for the entire problem definition."""
    offline_dim: int
    online_dim: int
    
    # offline_bounds must be a 2D tensor with the layout [2, d], where d is the
    # offline_dim. Row 0 contains lower bounds, and Row 1 contains upper bounds.
    offline_bounds: torch.Tensor
    
    design_points: List[DesignPoint]
    objectives: List[Objective]
    constraints: List[GlobalConstraint] = field(default_factory=list)
    
    # If provided, user_initial_points must have the same dtype and be on the
    # same device as offline_bounds to prevent silent errors in torch operations.
    user_initial_points: Optional[torch.Tensor] = None
    
    n_initial_samples: int = 10
    n_bo_iterations: int = 50
    batch_size: int = 1
    
    # Note: Increasing num_restarts and raw_samples can significantly increase
    # runtime. Tune downward for faster iteration and debugging.
    num_restarts: int = 10
    raw_samples: int = 512

def validate_optimization_config(cfg: OptimizationConfig):
    """
    Raise ValueError with a clear message if the OptimizationConfig is malformed.
    This provides early, informative error checking before a long run starts.
    """
    print("Validating optimization configuration...")
    if not isinstance(cfg.offline_dim, int) or cfg.offline_dim <= 0:
        raise ValueError("offline_dim must be a positive integer")
    
    if not isinstance(cfg.online_dim, int) or cfg.online_dim < 0:
        raise ValueError("online_dim must be a non-negative integer")
        
    if not isinstance(cfg.offline_bounds, torch.Tensor):
        raise ValueError("offline_bounds must be a torch.Tensor")
        
    if cfg.offline_bounds.shape != (2, cfg.offline_dim):
        raise ValueError(
            f"offline_bounds shape is {cfg.offline_bounds.shape}, but must be [2, d] "
            f"where d is offline_dim ({cfg.offline_dim})."
        )
        
    if cfg.user_initial_points is not None:
        if not isinstance(cfg.user_initial_points, torch.Tensor):
            raise ValueError("user_initial_points must be a torch.Tensor")
        if cfg.user_initial_points.shape[-1] != cfg.offline_dim:
            raise ValueError(
                f"The last dimension of user_initial_points ({cfg.user_initial_points.shape[-1]}) "
                f"must match offline_dim ({cfg.offline_dim})."
            )
        if cfg.user_initial_points.device != cfg.offline_bounds.device:
             raise ValueError("user_initial_points device must match offline_bounds device.")
        if cfg.user_initial_points.dtype != cfg.offline_bounds.dtype:
             raise ValueError("user_initial_points dtype must match offline_bounds dtype.")

    names = [dp.name for dp in cfg.design_points]
    if len(names) != len(set(names)):
        raise ValueError("DesignPoint names must be unique.")

    # Optional: Dry-run check for callables
    dummy_results_map = defaultdict(lambda: defaultdict(float))
    for obj in cfg.objectives:
        try:
            obj.eval_function(dummy_results_map)
        except Exception as e:
            print(f"Warning: Could not dry-run objective '{obj.name}'. Error: {e}")
            
    print("Configuration appears valid.")

