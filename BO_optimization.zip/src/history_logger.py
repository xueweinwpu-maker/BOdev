# -*- coding: utf-8 -*-
"""
Module for logging the full optimization history to a CSV file.
"""
import pandas as pd
from typing import List, Dict, Any
# ** FIX: Add the missing import for numpy **
import numpy as np
from src.bo_optimizer import BayesianOptimizer

def save_history_to_csv(optimizer: BayesianOptimizer, filename: str):
    """
    Saves the complete optimization history to a specified CSV file.
    
    Args:
        optimizer: The completed optimizer object containing the run history.
        filename: The full path, including directory, for the output CSV file.
    """
    print(f"\n--- Saving optimization history to '{filename}' ---")
    history_data = optimizer.full_run_history

    if not history_data:
        print("No history data to save.")
        return

    records = []
    for i, iteration_data in enumerate(history_data):
        record = {"evaluation": i + 1} # Use 1-based indexing for evaluations
        
        # Log offline variables
        for j, var in enumerate(iteration_data["offline_vars"]):
            record[f"offline_var_{j}"] = var
            
        # Log online variables
        for dp_name, online_vars in iteration_data["converged_online_vars"].items():
            if online_vars is not None:
                if isinstance(online_vars, (list, np.ndarray)):
                    for j, ovar in enumerate(online_vars):
                        record[f"{dp_name}_online_var_{j}"] = ovar
                else:
                     record[f"{dp_name}_online_var_0"] = online_vars


        # Log objectives
        for j, obj in enumerate(iteration_data["objectives"]):
            obj_name = optimizer.config.objectives[j].name.replace(" ", "_")
            record[f"obj_{obj_name}"] = obj

        # Log global constraints
        if "constraints" in iteration_data and iteration_data["constraints"] is not None:
            for j, con in enumerate(iteration_data["constraints"]):
                con_name = optimizer.config.constraints[j].name.replace(" ", "_")
                record[f"con_{con_name}"] = con

        # Log detailed results from each design point
        for dp_name, dp_results in iteration_data["design_point_results"].items():
            for key, value in dp_results.items():
                if isinstance(value, (int, float, np.number)):
                    record[f"{dp_name}_{key}"] = value

        record["convergence_metric"] = iteration_data["convergence_metric"]
        record["acqf_value"] = iteration_data["acqf_value"]
        records.append(record)
    
    df = pd.DataFrame(records)
    try:
        df.to_csv(filename, index=False)
        print("History saved successfully.")
    except Exception as e:
        print(f"Error saving history to CSV: {e}")

