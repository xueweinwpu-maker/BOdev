# -*- coding: utf-8 -*-
"""
The Black-Box wrapper.
This version provides more detailed inner-loop logging, showing the status
of local constraints at each step of the local optimization.
"""
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
from typing import Tuple, List, Dict, Any
import torch
import numpy as np
from scipy.optimize import minimize

from src.problem_structures import OptimizationConfig, DesignPoint

@dataclass
class InnerLoopHistory:
    """Stores the optimization history of a single inner-loop run."""
    online_vars_history: List[np.ndarray] = field(default_factory=list)
    objective_history: List[float] = field(default_factory=list)
    constraint_history: Dict[str, List[float]] = field(default_factory=dict)

class BlackBox(ABC):
    """Abstract base class for the black-box function."""
    def __init__(self, config: OptimizationConfig):
        self.config = config
        self.evaluation_counter = 0
        self.last_run_inner_histories: Dict[str, InnerLoopHistory] = {}
        self.warm_start_points: Dict[str, np.ndarray] = {}
        self.last_run_results_map: Dict[str, Dict[str, Any]] = {}
        self.dtype = config.offline_bounds.dtype
        self.device = config.offline_bounds.device

    @abstractmethod
    def evaluate(self, offline_vars_tensor: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        pass

@dataclass
class _CacheEntry:
    results: Dict[str, Any]

class AeroEvaluation(BlackBox):
    """
    The concrete implementation of the black-box for aerodynamic evaluation.
    """
    def __init__(self, config: OptimizationConfig):
        super().__init__(config)
        self.last_run_converged_online: Dict[str, np.ndarray] = {}

    def _inner_loop_optimize(self, offline_vars: np.ndarray, design_point: DesignPoint) -> Dict[str, Any]:
        cfg = design_point.inner_opt_config
        cache: Dict[Tuple, _CacheEntry] = {}
        history = InnerLoopHistory()

        def get_from_pipeline_or_cache(online_vars_tuple: Tuple) -> Dict[str, Any]:
            if online_vars_tuple not in cache:
                cache[online_vars_tuple] = _CacheEntry(
                    results=design_point.pipeline.run(offline_vars, np.array(online_vars_tuple))
                )
            return cache[online_vars_tuple].results

        def objective_for_sqp(online_vars: np.ndarray) -> float:
            return -get_from_pipeline_or_cache(tuple(online_vars)).get("objective", 0.0)

        inner_constraints_for_solver = []
        if cfg.constraints:
            for constraint in cfg.constraints:
                def constraint_func(online_vars: np.ndarray, c=constraint) -> float:
                    sim_results = get_from_pipeline_or_cache(tuple(online_vars))
                    return c.eval_function(sim_results)
                inner_constraints_for_solver.append({'type': 'ineq', 'fun': constraint_func})
                history.constraint_history[constraint.name] = []

        # ** UPDATE: Enhanced callback with constraint logging **
        def callback(xk):
            """Callback to store history and print debug info at each iteration."""
            current_results = get_from_pipeline_or_cache(tuple(xk))
            objective_value = current_results.get("objective", 0.0)
            
            log_msg = f"    - Inner-loop step: sweep_angle = {xk[0]:.4f}, objective = {objective_value:.4f}"
            
            # Add constraint info to the log message
            if cfg.constraints:
                con_msgs = []
                for constraint in cfg.constraints:
                    con_val = constraint.eval_function(current_results)
                    con_msgs.append(f"{constraint.name} = {con_val:.4f}")
                    history.constraint_history[constraint.name].append(con_val)
                log_msg += ", Constraints: (" + ", ".join(con_msgs) + ")"

            print(log_msg)

            history.online_vars_history.append(np.copy(xk))
            history.objective_history.append(objective_value)


        initial_guess = self.warm_start_points.get(design_point.name, cfg.x0)
        print(f"  - Starting inner loop for '{design_point.name}' with initial guess: {np.round(initial_guess, 4)}")

        result = minimize(
            fun=objective_for_sqp, x0=initial_guess, method=cfg.method,
            bounds=cfg.bounds, constraints=inner_constraints_for_solver,
            options={"maxiter": cfg.maxiter}, tol=cfg.tol, callback=callback
        )
        
        optimal_online_vars = result.x
        final_results = get_from_pipeline_or_cache(tuple(optimal_online_vars))
        
        is_feasible = True
        violated_constraints = []
        if cfg.constraints:
            for constraint in cfg.constraints:
                if constraint.eval_function(final_results) < 0:
                    is_feasible = False
                    violated_constraints.append(constraint.name)

        success_msg = "converged" if result.success else f"failed ({result.message})"
        feasibility_msg = "Feasible" if is_feasible else f"Infeasible (Violated: {', '.join(violated_constraints)})"
        print(f"  - Inner loop for '{design_point.name}' {success_msg} in {result.nit} iterations. Final state: {feasibility_msg}")
        
        if not is_feasible:
            print(f"  - WARNING: Inner loop for '{design_point.name}' failed to find a feasible solution.")
            print("             Returning a penalty value to the outer loop.")
            penalty_results = final_results.copy()
            
            is_minimization = design_point.pipeline.inner_loop_objective.startswith('-')
            penalty_value = 1e6 if is_minimization else -1e6
            
            metric_to_penalize = design_point.pipeline.inner_loop_objective.lstrip('-')
            penalty_results[metric_to_penalize] = penalty_value
            
            penalty_results["objective"] = penalty_value
            if metric_to_penalize in ["K", "-K"]:
                penalty_results["K"] = penalty_value
            
            self.warm_start_points[design_point.name] = optimal_online_vars
            self.last_run_converged_online[design_point.name] = optimal_online_vars
            return penalty_results

        self.warm_start_points[design_point.name] = optimal_online_vars
        self.last_run_converged_online[design_point.name] = optimal_online_vars
        self.last_run_inner_histories[design_point.name] = history

        return final_results

    def evaluate(self, offline_vars_tensor: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        self.last_run_inner_histories.clear()
        self.last_run_converged_online.clear()
        self.last_run_results_map.clear()
        
        offline_vars_batch = offline_vars_tensor.cpu().numpy()
        all_objectives_batch, all_constraints_batch = [], []

        for offline_vars in offline_vars_batch:
            self.evaluation_counter += 1
            print(f"\n--- Black-Box Evaluation #{self.evaluation_counter} ---\nOffline Vars: {np.round(offline_vars, 4)}")
            
            results_map: Dict[str, Dict[str, Any]] = {}
            for dp in self.config.design_points:
                if dp.inner_opt_config:
                    final_results = self._inner_loop_optimize(offline_vars, dp)
                else:
                    final_results = dp.pipeline.run(offline_vars, None)
                    self.last_run_converged_online[dp.name] = None
                
                results_map[dp.name] = final_results
            
            self.last_run_results_map = results_map

            objective_values = [obj.eval_function(results_map) for obj in self.config.objectives]
            all_objectives_batch.append(objective_values)
            
            constraint_values = [con.eval_function(results_map) for con in self.config.constraints] if self.config.constraints else []
            all_constraints_batch.append(constraint_values)

        print("--- Evaluation Complete ---")
        
        objectives_tensor = torch.tensor(all_objectives_batch, dtype=self.dtype, device=self.device)
        constraints_tensor = torch.tensor(all_constraints_batch, dtype=self.dtype, device=self.device) if self.config.constraints else torch.empty(len(all_objectives_batch), 0, dtype=self.dtype, device=self.device)
        
        return objectives_tensor, constraints_tensor

